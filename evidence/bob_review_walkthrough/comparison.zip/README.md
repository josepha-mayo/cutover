# Cutover before/after release review

These are two independent, fresh SQL rehearsals of the same contract and evaluator.
The `baseline/` and `candidate/` folders each contain a complete review packet.
Run the audit command in each folder README from a checkout of Cutover with
the matching engine hash. The auditor replays every retained claim.

To verify both reports, the comparison manifest, reviews and witnesses in
one step, run `python -m cutover.audit_bundle --bundle PATH_TO_ZIP`.

Baseline: blocked 108/124 · f7ff94084d775c2eb236ad3f2f1e65a52a6d56b46ffe885672b36a8dcc6ee6e4
Candidate: pass 116/116 · 930c2f30ccd10a81bc34cffc23dbcdceb45d60885d1609ac1a2aa698baa74da6

The comparison.json file counts paired probes only when their payload and
action sequence match. Different migration SQL sequences have different
statement boundaries, so their window failures are reported separately.
A passing bounded SQLite rehearsal is not production deployment approval.
