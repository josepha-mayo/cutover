"""Check packaged fixed inputs before independently executing a candidate."""
import argparse, hashlib, json, subprocess, sys, uuid
from pathlib import Path
root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--candidate', type=Path)
args = parser.parse_args()
try:
    manifest = json.loads((root/'WORKSPACE_MANIFEST.json').read_text(encoding='utf-8'))
    for name, expected in manifest['files'].items():
        if hashlib.sha256((root/name).read_bytes()).hexdigest() != expected:
            raise ValueError('Packaged fixed file changed: ' + name)
    print('Packaged fixed inputs match the recorded inventory.')
    if args.candidate:
        candidate = args.candidate.resolve()
        output = root/'work'/('verification-' + uuid.uuid4().hex)
        output.mkdir(parents=True)
        print('Evidence directory: ' + str(output), flush=True)
        result = subprocess.run([sys.executable, '-m', 'cutover', '--contract',
            str(root/'contract.json'), '--plan', str(candidate), '--output',
            str(output/'report.json'), '--markdown',
            str(output/'review.md')], cwd=root, timeout=120)
        sys.exit(result.returncode)
except (OSError, ValueError, KeyError, subprocess.TimeoutExpired) as exc:
    print('UNVERIFIED: ' + str(exc), file=sys.stderr)
    sys.exit(2)
