# Local Bob repair workspace

Extract this ZIP into a new folder. Use synthetic data in the hosted demo;
run Cutover locally for private schemas. This archive contains your selected
blocked inputs and a fixed evaluator, not bundled passing reference repairs.
Inspect the source before running it. No API keys or account information are included.

1. With Python 3.10+ available, run `python verify_workspace.py`.
2. Create a local environment: `python -m venv .venv`.
3. Install the pinned MCP SDK using that environment's Python:
   `.venv/Scripts/python.exe -m pip install -r requirements-mcp.txt` on Windows,
   or `.venv/bin/python -m pip install -r requirements-mcp.txt` on Linux/macOS.
4. Run that Python with `configure_bob.py`. It creates absolute local paths in
   `.bob/mcp.json`; all MCP auto-approval permissions remain empty.
5. Open the extracted folder in Bob IDE. Review its trust/configuration prompts,
   confirm the Cutover MCP connection, choose Cutover local repair, and submit TASK.md.
6. Independently check the saved result:
   `python verify_workspace.py --candidate work/bob-candidate.json`.
   Exit 0 means this suite passed, 1 means blocked, and other errors remain unverified.
   Each attempt retains its report and Markdown in a new folder under work/. Import the candidate into
   the browser to compare it and, on a pass, export a separately verified PR gate kit.

Hashes detect changes against this package's inventory, not publisher authenticity.
Deliberately replacing the inventory defeats that check. Bob IDE access is separate;
the archive does not invoke Bob, purchase credits, or claim Bob authored a candidate.
