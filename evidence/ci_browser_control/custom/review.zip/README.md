# Cutover release review

Verdict: PASS (124/124 probes)
Plan SHA-256: 094e61d8f32f2dc6b2204b41316fb719acbfcfadf30ba9d791254607f65ea42d
Contract SHA-256: f623f640609056afcbb25a2b59b1aa7d0356c0a4477b8656b9c4e8f02e68798d
Engine SHA-256: 9b315f8a9b9d434f4de5f46b94aefcc15b635bab64ffd69f1bae989361e50aeb

The JSON and Markdown record one executed rehearsal. From a checkout of the
Cutover source with the matching engine hash, rerun every replayable claim:

    python -m cutover.audit_report --contract contract.json --plan plan.json --report report.json

Exit 0 means verified pass, 1 means verified block, and 2 means unverified.
To verify this entire ZIP, including its Markdown and any witness, run
`python -m cutover.audit_bundle --bundle PATH_TO_ZIP` from the source checkout.
A passing report is bounded evidence, not deployment approval. The archive
is not signed; creation time, runtime and host SQLite version are self-reported.
