#!/usr/bin/env python3
# Cutover standalone witness. Runs candidate SQL in disposable in-memory SQLite.
import json
import sqlite3
import time
import uuid

PROBE = 'old_to_new-0'
FAILURE_KIND = 'data_mismatch'
PLAN_HASH = 'd078a43429aea5c4ca76aac8a3459efd9524ee12fd68fe3625438c0c0664307c'
SCHEMA = 'CREATE TABLE stock_items (id INTEGER PRIMARY KEY, pick_bin TEXT NOT NULL);'
SEED_SQL = 'INSERT INTO stock_items (id, pick_bin) VALUES (?, ?)'
SEED = [[11, 'A-01'], [22, 'B-02'], [33, 'C-03']]
STEPS = [{'action': 'migrate', 'status': 'pass', 'sql': 'ALTER TABLE stock_items ADD COLUMN fulfillment_bin TEXT;\nCREATE TRIGGER sync_insert_to_fulfillment AFTER INSERT ON stock_items\nWHEN NEW.fulfillment_bin IS NULL\nBEGIN\n  UPDATE stock_items SET fulfillment_bin = NEW.pick_bin WHERE id = NEW.id;\nEND;\nUPDATE stock_items SET fulfillment_bin = pick_bin WHERE fulfillment_bin IS NULL;'}, {'action': 'old.write', 'status': 'pass', 'sql': 'UPDATE stock_items SET pick_bin = :value WHERE id = :id', 'params': {'id': 11, 'value': 'R-07'}}, {'action': 'new.read', 'status': 'fail', 'sql': 'SELECT id, fulfillment_bin AS value FROM stock_items ORDER BY id', 'expected': {'11': 'R-07', '22': 'B-02', '33': 'C-03'}, 'actual': {'11': 'A-01', '22': 'B-02', '33': 'C-03'}}]

def reproduce():
    database = f"file:cutover-{uuid.uuid4().hex}?mode=memory&cache=shared"
    deadline = time.monotonic() + 3
    denied = {sqlite3.SQLITE_ATTACH, sqlite3.SQLITE_DETACH, sqlite3.SQLITE_PRAGMA,
              sqlite3.SQLITE_TRANSACTION, sqlite3.SQLITE_SAVEPOINT,
              sqlite3.SQLITE_CREATE_TEMP_TABLE, sqlite3.SQLITE_CREATE_TEMP_VIEW,
              sqlite3.SQLITE_CREATE_TEMP_TRIGGER, sqlite3.SQLITE_CREATE_TEMP_INDEX,
              sqlite3.SQLITE_DROP_TEMP_TABLE, sqlite3.SQLITE_DROP_TEMP_VIEW,
              sqlite3.SQLITE_DROP_TEMP_TRIGGER, sqlite3.SQLITE_DROP_TEMP_INDEX}

    def authorize(action, a, b, database, source):
        if action in denied or (action == sqlite3.SQLITE_FUNCTION and
                                str(b).lower() in ('load_extension', 'writefile', 'readfile')):
            return sqlite3.SQLITE_DENY
        return sqlite3.SQLITE_OK

    def open_connection():
        db = sqlite3.connect(database, uri=True, isolation_level=None)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA recursive_triggers=ON')
        db.set_authorizer(authorize)
        db.setlimit(sqlite3.SQLITE_LIMIT_LENGTH, 1000000)
        db.setlimit(sqlite3.SQLITE_LIMIT_SQL_LENGTH, 20000)
        db.setlimit(sqlite3.SQLITE_LIMIT_ATTACHED, 0)
        db.set_progress_handler(lambda: int(time.monotonic() > deadline), 1000)
        return db

    db = old_db = new_db = None
    try:
        db = open_connection()
        db.executescript(SCHEMA)
        db.executemany(SEED_SQL, SEED)
        old_db = open_connection()
        new_db = open_connection()
        for step in STEPS:
            action = step['action']
            worker_db = (old_db if action.startswith('old.') else
                         new_db if action.startswith('new.') else db)
            if action == 'migrate' or action.startswith('migration.statement.'):
                db.executescript(step['sql'])
            elif action.endswith('.write') or action.endswith('.insert'):
                count = worker_db.execute(step['sql'], step['params']).rowcount
                if count != 1:
                    raise AssertionError(f'{action} affected {count} records instead of one')
            else:
                rows = worker_db.execute(step['sql']).fetchmany(100)
                actual = {str(row['id']): row['value'] for row in rows}
                recorded = {str(key): value for key, value in step['actual'].items()}
                expected = {str(key): value for key, value in step['expected'].items()}
                if actual != recorded:
                    raise AssertionError(f'{action} no longer matches the recorded observation')
                if step['status'] == 'fail':
                    if actual == expected:
                        raise AssertionError('The recorded data gap is no longer reproducible')
                    print(json.dumps({'status': 'REPRODUCED', 'probe': PROBE,
                                      'failure_kind': FAILURE_KIND, 'plan_hash': PLAN_HASH,
                                      'expected': expected, 'actual': actual,
                                      'sqlite_version': sqlite3.sqlite_version},
                                     ensure_ascii=False, sort_keys=True))
                    return
                if actual != expected:
                    raise AssertionError(f'{action} diverged before the recorded failure')
        raise AssertionError('The recorded failure step was not reached')
    finally:
        for active in (new_db, old_db, db):
            if active is not None:
                active.close()


if __name__ == '__main__':
    reproduce()
