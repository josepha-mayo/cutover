# Cutover release review

Verdict: BLOCKED (108/124 probes)
Plan SHA-256: 7e7bc349a783c824777fa99a4e2fdf1c245aa7f1f1e404421fa62541cf2ff252
Contract SHA-256: ecf66707fc8fe5a8a59f4dbfda92bed4377352cb190c6ad23d69271c8b325418
Engine SHA-256: 9b315f8a9b9d434f4de5f46b94aefcc15b635bab64ffd69f1bae989361e50aeb

The JSON and Markdown record one executed rehearsal. From a checkout of the
Cutover source with the matching engine hash, rerun every replayable claim:

    python -m cutover.audit_report --contract contract.json --plan plan.json --report report.json

Exit 0 means verified pass, 1 means verified block, and 2 means unverified.
To verify this entire ZIP, including its Markdown and any witness, run
`python -m cutover.audit_bundle --bundle PATH_TO_ZIP` from the source checkout.
A passing report is bounded evidence, not deployment approval. The archive
is not signed; creation time, runtime and host SQLite version are self-reported.

Run `python -I witness.py` to reproduce the recorded data gap.
