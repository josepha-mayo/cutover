#!/usr/bin/env python3
# Cutover standalone witness. Runs candidate SQL in disposable in-memory SQLite.
import json
import sqlite3
import time
import uuid

PROBE = 'window_write_after_2-0'
FAILURE_KIND = 'data_mismatch'
PLAN_HASH = '7e7bc349a783c824777fa99a4e2fdf1c245aa7f1f1e404421fa62541cf2ff252'
SCHEMA = 'CREATE TABLE orders (id INTEGER PRIMARY KEY, delivery_address TEXT NOT NULL);'
SEED_SQL = 'INSERT INTO orders (id, delivery_address) VALUES (?, ?)'
SEED = [[101, '4 Broad Street'], [102, '9 Station Road']]
STEPS = [{'action': 'migration.statement.0', 'status': 'pass', 'sql': 'ALTER TABLE orders ADD COLUMN shipping_address TEXT;'}, {'action': 'migration.statement.1', 'status': 'pass', 'sql': 'UPDATE orders SET shipping_address = delivery_address;'}, {'action': 'old.write', 'status': 'pass', 'sql': 'UPDATE orders SET delivery_address = :value WHERE id = :id', 'params': {'id': 101, 'value': '18 Marina Road'}}, {'action': 'old.read', 'status': 'pass', 'sql': 'SELECT id, delivery_address AS value FROM orders ORDER BY id', 'expected': {'101': '18 Marina Road', '102': '9 Station Road'}, 'actual': {'101': '18 Marina Road', '102': '9 Station Road'}}, {'action': 'migration.statement.2', 'status': 'pass', 'sql': '-- Triggers arrive only after the backfill window.\n-- Preserve both reader contracts throughout the rollback window.\nCREATE TRIGGER sync_old_update AFTER UPDATE OF delivery_address ON orders\nWHEN NEW.delivery_address IS NOT NEW.shipping_address\nBEGIN\n  UPDATE orders SET shipping_address = NEW.delivery_address WHERE id = NEW.id;\nEND;'}, {'action': 'migration.statement.3', 'status': 'pass', 'sql': 'CREATE TRIGGER sync_new_update AFTER UPDATE OF shipping_address ON orders\nWHEN NEW.shipping_address IS NOT NEW.delivery_address\nBEGIN\n  UPDATE orders SET delivery_address = NEW.shipping_address WHERE id = NEW.id;\nEND;'}, {'action': 'migration.statement.4', 'status': 'pass', 'sql': 'CREATE TRIGGER sync_old_insert AFTER INSERT ON orders\nWHEN NEW.shipping_address IS NULL\nBEGIN\n  UPDATE orders SET shipping_address = NEW.delivery_address WHERE id = NEW.id;\nEND;'}, {'action': 'new.read', 'status': 'fail', 'sql': 'SELECT id, shipping_address AS value FROM orders ORDER BY id', 'expected': {'101': '18 Marina Road', '102': '9 Station Road'}, 'actual': {'101': '4 Broad Street', '102': '9 Station Road'}}]

def reproduce():
    database = f"file:cutover-{uuid.uuid4().hex}?mode=memory&cache=shared"
    deadline = time.monotonic() + 3
    denied = {sqlite3.SQLITE_ATTACH, sqlite3.SQLITE_DETACH, sqlite3.SQLITE_PRAGMA,
              sqlite3.SQLITE_TRANSACTION, sqlite3.SQLITE_SAVEPOINT,
              sqlite3.SQLITE_CREATE_TEMP_TABLE, sqlite3.SQLITE_CREATE_TEMP_VIEW,
              sqlite3.SQLITE_CREATE_TEMP_TRIGGER, sqlite3.SQLITE_CREATE_TEMP_INDEX,
              sqlite3.SQLITE_DROP_TEMP_TABLE, sqlite3.SQLITE_DROP_TEMP_VIEW,
              sqlite3.SQLITE_DROP_TEMP_TRIGGER, sqlite3.SQLITE_DROP_TEMP_INDEX}

    def authorize(action, a, b, database, source):
        if action in denied or (action == sqlite3.SQLITE_FUNCTION and
                                str(b).lower() in ('load_extension', 'writefile', 'readfile')):
            return sqlite3.SQLITE_DENY
        return sqlite3.SQLITE_OK

    def open_connection():
        db = sqlite3.connect(database, uri=True, isolation_level=None)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA recursive_triggers=ON')
        db.set_authorizer(authorize)
        db.setlimit(sqlite3.SQLITE_LIMIT_LENGTH, 1000000)
        db.setlimit(sqlite3.SQLITE_LIMIT_SQL_LENGTH, 20000)
        db.setlimit(sqlite3.SQLITE_LIMIT_ATTACHED, 0)
        db.set_progress_handler(lambda: int(time.monotonic() > deadline), 1000)
        return db

    db = old_db = new_db = None
    try:
        db = open_connection()
        db.executescript(SCHEMA)
        db.executemany(SEED_SQL, SEED)
        old_db = open_connection()
        new_db = open_connection()
        for step in STEPS:
            action = step['action']
            worker_db = (old_db if action.startswith('old.') else
                         new_db if action.startswith('new.') else db)
            if action == 'migrate' or action.startswith('migration.statement.'):
                db.executescript(step['sql'])
            elif action.endswith('.write') or action.endswith('.insert'):
                count = worker_db.execute(step['sql'], step['params']).rowcount
                if count != 1:
                    raise AssertionError(f'{action} affected {count} records instead of one')
            else:
                rows = worker_db.execute(step['sql']).fetchmany(100)
                actual = {str(row['id']): row['value'] for row in rows}
                recorded = {str(key): value for key, value in step['actual'].items()}
                expected = {str(key): value for key, value in step['expected'].items()}
                if actual != recorded:
                    raise AssertionError(f'{action} no longer matches the recorded observation')
                if step['status'] == 'fail':
                    if actual == expected:
                        raise AssertionError('The recorded data gap is no longer reproducible')
                    print(json.dumps({'status': 'REPRODUCED', 'probe': PROBE,
                                      'failure_kind': FAILURE_KIND, 'plan_hash': PLAN_HASH,
                                      'expected': expected, 'actual': actual,
                                      'sqlite_version': sqlite3.sqlite_version},
                                     ensure_ascii=False, sort_keys=True))
                    return
                if actual != expected:
                    raise AssertionError(f'{action} diverged before the recorded failure')
        raise AssertionError('The recorded failure step was not reached')
    finally:
        for active in (new_db, old_db, db):
            if active is not None:
                active.close()


if __name__ == '__main__':
    reproduce()
