# Cutover CI handoff kit

Fresh rehearsal: PASS 124/124 bounded probes.
Plan SHA-256: 094e61d8f32f2dc6b2204b41316fb719acbfcfadf30ba9d791254607f65ea42d
Contract SHA-256: 807df59ffcecefe490e480ecaa03e4e7ca023ad61cf9c9c462ade50f7bae9de9
Engine SHA-256: 9b315f8a9b9d434f4de5f46b94aefcc15b635bab64ffd69f1bae989361e50aeb

From a checkout of the Cutover repository, copy the two JSON files under
`ci/` into the matching paths. Add the object in `manifest-entry.json`
to the `ci/cases.json` array; choose a unique slug if needed. Run:

    python -m ci.discover_cases
    python -m cutover.audit_report --contract ci/release-my-release-contract.json --plan ci/release-my-release-candidate.json --report evidence/report.json

Commit the files and open a PR. GitHub Actions will create a separate
review job with retained evidence for this case. This kit contains
freshly executed and independently replayed synthetic SQLite evidence,
not deployment approval. Check
the source SQL, privacy, dialect and operational rollback plan yourself.
The archive is not signed; its self-reported timestamps are not proof
of origin or IBM Bob authorship.

## Prove this gate can go red

The same contract also blocked the unsafe control at 44/100 probes. Its first failing write is retained in `evidence/unsafe-control-report.json` and `evidence/unsafe-control-witness.py`. From the repository checkout, run:

    python ci/review_gate.py --contract ci/release-my-release-contract.json --plan ci/release-my-release-unsafe-control.json --output-dir work/ci-negative-control
    # Expected exit 1 and classification verified_block.
    python ci/review_gate.py --contract ci/release-my-release-contract.json --plan ci/release-my-release-candidate.json --output-dir work/ci-positive-control
    # Expected exit 0 and classification verified_pass.

The unsafe control is not in `manifest-entry.json`: do not add it to a normal green PR.
