# Cutover review: One-time backfill without a compatibility bridge

**Verdict:** BLOCKED — 44/100 rollout and window probes passed.

**Contract:** My release (`custom`)

| Evidence group | Passed | Total |
| --- | ---: | ---: |
| Same-version baseline | 8 | 8 |
| Completed rollout | 28 | 76 |
| Migration-statement windows | 16 | 24 |

The baseline is separate from the rollout total. Each probe executes against a fresh disposable SQLite database and checks acknowledged values against an independent ledger.

## Shortest observed failing replay

Probe: **`old_to_new-0`** — Old write → new read

Input:

~~~json
"R-07"
~~~

Row shown in this replay: `1`.

Seed IDs checked before this verdict:

~~~json
[
  1
]
~~~

### 1. migrate — pass

Connection: **migration**.

Executed SQL:

~~~sql
ALTER TABLE "items" ADD COLUMN "destination" TEXT;
UPDATE "items" SET "destination" = "location";
~~~

Migration statement executed against a fresh in-memory database.

### 2. old.write — pass

Connection: **old**.

Executed SQL:

~~~sql
UPDATE "items" SET "location" = :value WHERE id = :id
~~~

Bound inputs:

~~~json
{
  "id": 1,
  "value": "R-07"
}
~~~

Write acknowledged; independent ledger updated.

### 3. new.read — fail

Connection: **new**.

Executed SQL:

~~~sql
SELECT id, "destination" AS value FROM "items" ORDER BY id
~~~

Expected ledger:

~~~json
{
  "1": "R-07",
  "2": "B-02"
}
~~~

Observed:

~~~json
{
  "1": "A-01",
  "2": "B-02"
}
~~~

A reader cannot see the latest acknowledged data.

Failure: **data\_mismatch** — A reader cannot see the latest acknowledged data.

## Evidence identity

- Plan SHA-256: `427bff109d3fb6d29d10f23146dc0530e050a71020d8eb6b360b44543c7de375`
- Contract SHA-256: `807df59ffcecefe490e480ecaa03e4e7ca023ad61cf9c9c462ade50f7bae9de9`
- Suite SHA-256: `11ae36583c3623b8fe6438a70b1621b457ef64f73621b13d2f0225638e73d13b`
- Engine SHA-256: `9b315f8a9b9d434f4de5f46b94aefcc15b635bab64ffd69f1bae989361e50aeb`
- SQLite version: `3.40.1`
- Generated UTC: `2026-09-25T22:05:08.713879+00:00`

## Scope and limits

SQLite user-supplied contract, separate migration/old/new connections to one disposable in-memory database, target-column postconditions, every seeded record for update probes, every ordered seed pair across rotating two-write probes, two new record IDs for insert probes, bounded sequential interleavings and old-worker read checks at every completed statement boundary. Not a production deployment approval.

- No concurrent transactions, lock timing or network failures modeled.
- No PostgreSQL, MySQL or ORM behavior claimed.
- Writes between migration statements are modeled; mid-statement interruption and lock timing are not.
- Contract/drop-column phase is deferred until old workers and rollback windows are retired.
- Each ordered seed pair is covered somewhere in a passing full suite, but not under every schedule and payload combination.
- Passing covers only the fixed adapters, seed data and reported schedules.

This report documents executed SQL only. It does not establish IBM Bob authorship, production safety, or behavior outside the reported contract and schedules.
