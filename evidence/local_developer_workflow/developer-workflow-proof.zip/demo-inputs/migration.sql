ALTER TABLE "shipments" ADD COLUMN "dispatch_bay" TEXT;
UPDATE "shipments" SET "dispatch_bay" = "loading_bay";
