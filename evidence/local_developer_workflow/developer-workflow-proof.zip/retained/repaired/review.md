# Independently verified Cutover packet

Every retained report and packaged companion file passed independent replay and format verification. This is bounded SQLite evidence, not production approval or authenticated authorship.

## Review verdict

| Executed plan | Verdict | Full suite passed | Completed-rollout failures | Migration-window failures |
| --- | --- | --- | --- | --- |
| Baseline | BLOCKED | 55/125 | 60/95 | 10/30 |
| Candidate | PASS | 155/155 | 0/95 | 0/60 |

Window counts describe each plan separately. Different statement sequences create different tested boundaries; a smaller denominator does not imply equivalent coverage. The packet retains both full reports.

## Measured comparison

~~~json
{
  "paired_probes": 95,
  "regressed_probe_ids": [],
  "resolved": 60,
  "regressed": 0,
  "window_probes_paired": false,
  "interpretation": "Different SQL sequences: statement windows are evaluated separately, not paired by step number."
}
~~~

## Executed SQL changes

Textual differences do not establish which SQL line caused the measured change.

### migration

Changed lines (- baseline, + candidate). Line endings are normalized for this display; the full SQL below and the packet retain the executed strings.

~~~diff
--- baseline/migration.sql
+++ candidate/migration.sql
@@ -1,2 +1,17 @@
-ALTER TABLE "shipments" ADD COLUMN "dispatch_bay" TEXT;
-UPDATE "shipments" SET "dispatch_bay" = "loading_bay";
+ALTER TABLE shipments ADD COLUMN dispatch_bay TEXT;
+CREATE TRIGGER sync_old_update AFTER UPDATE OF loading_bay ON shipments
+WHEN NEW.loading_bay IS NOT NEW.dispatch_bay
+BEGIN
+  UPDATE shipments SET dispatch_bay = NEW.loading_bay WHERE id = NEW.id;
+END;
+CREATE TRIGGER sync_new_update AFTER UPDATE OF dispatch_bay ON shipments
+WHEN NEW.dispatch_bay IS NOT NEW.loading_bay
+BEGIN
+  UPDATE shipments SET loading_bay = NEW.dispatch_bay WHERE id = NEW.id;
+END;
+CREATE TRIGGER sync_old_insert AFTER INSERT ON shipments
+WHEN NEW.dispatch_bay IS NULL
+BEGIN
+  UPDATE shipments SET dispatch_bay = NEW.loading_bay WHERE id = NEW.id;
+END;
+UPDATE shipments SET dispatch_bay = loading_bay;
~~~

Pinned baseline:

~~~sql
ALTER TABLE "shipments" ADD COLUMN "dispatch_bay" TEXT;
UPDATE "shipments" SET "dispatch_bay" = "loading_bay";
~~~

Current candidate:

~~~sql
ALTER TABLE shipments ADD COLUMN dispatch_bay TEXT;
CREATE TRIGGER sync_old_update AFTER UPDATE OF loading_bay ON shipments
WHEN NEW.loading_bay IS NOT NEW.dispatch_bay
BEGIN
  UPDATE shipments SET dispatch_bay = NEW.loading_bay WHERE id = NEW.id;
END;
CREATE TRIGGER sync_new_update AFTER UPDATE OF dispatch_bay ON shipments
WHEN NEW.dispatch_bay IS NOT NEW.loading_bay
BEGIN
  UPDATE shipments SET loading_bay = NEW.dispatch_bay WHERE id = NEW.id;
END;
CREATE TRIGGER sync_old_insert AFTER INSERT ON shipments
WHEN NEW.dispatch_bay IS NULL
BEGIN
  UPDATE shipments SET dispatch_bay = NEW.loading_bay WHERE id = NEW.id;
END;
UPDATE shipments SET dispatch_bay = loading_bay;
~~~

## Pinned baseline report

# Cutover review: One-time backfill: edit and rehearse before use

**Verdict:** BLOCKED — 55/125 rollout and window probes passed.

**Contract:** Local dispatch handoff (`custom`)

| Evidence group | Passed | Total |
| --- | ---: | ---: |
| Same-version baseline | 10 | 10 |
| Completed rollout | 35 | 95 |
| Migration-statement windows | 20 | 30 |

The baseline is separate from the rollout total. Each probe executes against a fresh disposable SQLite database and checks acknowledged values against an independent ledger.

## Shortest observed failing replay

Probe: **`old_to_new-0`** — Old write → new read

Input:

~~~json
"GATE-09"
~~~

Row shown in this replay: `1`.

Seed IDs checked before this verdict:

~~~json
[
  1
]
~~~

### 1. migrate — pass

Connection: **migration**.

Executed SQL:

~~~sql
ALTER TABLE "shipments" ADD COLUMN "dispatch_bay" TEXT;
UPDATE "shipments" SET "dispatch_bay" = "loading_bay";
~~~

Migration statement executed against a fresh in-memory database.

### 2. old.write — pass

Connection: **old**.

Executed SQL:

~~~sql
UPDATE "shipments" SET "loading_bay" = :value WHERE id = :id
~~~

Bound inputs:

~~~json
{
  "id": 1,
  "value": "GATE-09"
}
~~~

Write acknowledged; independent ledger updated.

### 3. new.read — fail

Connection: **new**.

Executed SQL:

~~~sql
SELECT id, "dispatch_bay" AS value FROM "shipments" ORDER BY id
~~~

Expected ledger:

~~~json
{
  "1": "GATE-09",
  "2": "東京-棚"
}
~~~

Observed:

~~~json
{
  "1": "O'Connell",
  "2": "東京-棚"
}
~~~

A reader cannot see the latest acknowledged data.

Failure: **data\_mismatch** — A reader cannot see the latest acknowledged data.

## Evidence identity

- Plan SHA-256: `3808c076d9d8e162f12b390f63d8207a83a57a00edb36a12463a6303b2780ba4`
- Contract SHA-256: `105ccaaee80a5c9b37ffee2b81bce733dd14b0cc6085af4dc66f7986e931acea`
- Suite SHA-256: `e4e586b3b3959034498f7e0c89380d4ae8c7b61e8a33c9b864bc21c25a37bd58`
- Engine SHA-256: `9b315f8a9b9d434f4de5f46b94aefcc15b635bab64ffd69f1bae989361e50aeb`
- SQLite version: `3.50.4`
- Generated UTC: `2026-09-27T05:10:45.850389+00:00`

## Scope and limits

SQLite user-supplied contract, separate migration/old/new connections to one disposable in-memory database, target-column postconditions, every seeded record for update probes, every ordered seed pair across rotating two-write probes, two new record IDs for insert probes, bounded sequential interleavings and old-worker read checks at every completed statement boundary. Not a production deployment approval.

- No concurrent transactions, lock timing or network failures modeled.
- No PostgreSQL, MySQL or ORM behavior claimed.
- Writes between migration statements are modeled; mid-statement interruption and lock timing are not.
- Contract/drop-column phase is deferred until old workers and rollback windows are retired.
- Each ordered seed pair is covered somewhere in a passing full suite, but not under every schedule and payload combination.
- Passing covers only the fixed adapters, seed data and reported schedules.

This report documents executed SQL only. It does not establish IBM Bob authorship, production safety, or behavior outside the reported contract and schedules.


## Current candidate report

# Cutover review: One-time backfill: edit and rehearse before use

**Verdict:** PASS — 155/155 rollout and window probes passed.

**Contract:** Local dispatch handoff (`custom`)

| Evidence group | Passed | Total |
| --- | ---: | ---: |
| Same-version baseline | 10 | 10 |
| Completed rollout | 95 | 95 |
| Migration-statement windows | 60 | 60 |

The baseline is separate from the rollout total. Each probe executes against a fresh disposable SQLite database and checks acknowledged values against an independent ledger.

## Example passing migration-window replay

Probe: **`window_write_after_0-0`** — Old write after migration step 0/5 → new read

Input:

~~~json
"GATE-09"
~~~

Row shown in this replay: `1`.

Seed IDs checked before this verdict:

~~~json
[
  1,
  2
]
~~~

### 1. old.write — pass

Connection: **old**.

Executed SQL:

~~~sql
UPDATE "shipments" SET "loading_bay" = :value WHERE id = :id
~~~

Bound inputs:

~~~json
{
  "id": 1,
  "value": "GATE-09"
}
~~~

Write acknowledged; independent ledger updated.

### 2. old.read — pass

Connection: **old**.

Executed SQL:

~~~sql
SELECT id, "loading_bay" AS value FROM "shipments" ORDER BY id
~~~

Expected ledger:

~~~json
{
  "1": "GATE-09",
  "2": "東京-棚"
}
~~~

Observed:

~~~json
{
  "1": "GATE-09",
  "2": "東京-棚"
}
~~~

All 2 records match the independent write ledger.

### 3. migration.statement.0 — pass

Connection: **migration**.

Executed SQL:

~~~sql
ALTER TABLE shipments ADD COLUMN dispatch_bay TEXT;
~~~

Migration statement executed against a fresh in-memory database.

### 4. migration.statement.1 — pass

Connection: **migration**.

Executed SQL:

~~~sql
CREATE TRIGGER sync_old_update AFTER UPDATE OF loading_bay ON shipments
WHEN NEW.loading_bay IS NOT NEW.dispatch_bay
BEGIN
  UPDATE shipments SET dispatch_bay = NEW.loading_bay WHERE id = NEW.id;
END;
~~~

Migration statement executed against a fresh in-memory database.

### 5. migration.statement.2 — pass

Connection: **migration**.

Executed SQL:

~~~sql
CREATE TRIGGER sync_new_update AFTER UPDATE OF dispatch_bay ON shipments
WHEN NEW.dispatch_bay IS NOT NEW.loading_bay
BEGIN
  UPDATE shipments SET loading_bay = NEW.dispatch_bay WHERE id = NEW.id;
END;
~~~

Migration statement executed against a fresh in-memory database.

### 6. migration.statement.3 — pass

Connection: **migration**.

Executed SQL:

~~~sql
CREATE TRIGGER sync_old_insert AFTER INSERT ON shipments
WHEN NEW.dispatch_bay IS NULL
BEGIN
  UPDATE shipments SET dispatch_bay = NEW.loading_bay WHERE id = NEW.id;
END;
~~~

Migration statement executed against a fresh in-memory database.

### 7. migration.statement.4 — pass

Connection: **migration**.

Executed SQL:

~~~sql
UPDATE shipments SET dispatch_bay = loading_bay;
~~~

Migration statement executed against a fresh in-memory database.

### 8. new.read — pass

Connection: **new**.

Executed SQL:

~~~sql
SELECT id, "dispatch_bay" AS value FROM "shipments" ORDER BY id
~~~

Expected ledger:

~~~json
{
  "1": "GATE-09",
  "2": "東京-棚"
}
~~~

Observed:

~~~json
{
  "1": "GATE-09",
  "2": "東京-棚"
}
~~~

All 2 records match the independent write ledger.

### 9. target.check — pass

Connection: **migration**.

Executed SQL:

~~~sql
SELECT id, "dispatch_bay" AS value FROM "shipments" ORDER BY id
~~~

Expected ledger:

~~~json
{
  "1": "GATE-09",
  "2": "東京-棚"
}
~~~

Observed:

~~~json
{
  "1": "GATE-09",
  "2": "東京-棚"
}
~~~

Required target column matches the independent write ledger.

**A pass is bounded to this suite; it is not a deployment approval.**

## Evidence identity

- Plan SHA-256: `898a68053049f1b7becfff9032f798c35bf57d958fd738f2b7745b26b77a1bdf`
- Contract SHA-256: `105ccaaee80a5c9b37ffee2b81bce733dd14b0cc6085af4dc66f7986e931acea`
- Suite SHA-256: `e4e586b3b3959034498f7e0c89380d4ae8c7b61e8a33c9b864bc21c25a37bd58`
- Engine SHA-256: `9b315f8a9b9d434f4de5f46b94aefcc15b635bab64ffd69f1bae989361e50aeb`
- SQLite version: `3.50.4`
- Generated UTC: `2026-09-27T05:10:45.546199+00:00`

## Scope and limits

SQLite user-supplied contract, separate migration/old/new connections to one disposable in-memory database, target-column postconditions, every seeded record for update probes, every ordered seed pair across rotating two-write probes, two new record IDs for insert probes, bounded sequential interleavings and old-worker read checks at every completed statement boundary. Not a production deployment approval.

- No concurrent transactions, lock timing or network failures modeled.
- No PostgreSQL, MySQL or ORM behavior claimed.
- Writes between migration statements are modeled; mid-statement interruption and lock timing are not.
- Contract/drop-column phase is deferred until old workers and rollback windows are retired.
- Each ordered seed pair is covered somewhere in a passing full suite, but not under every schedule and payload combination.
- Passing covers only the fixed adapters, seed data and reported schedules.

This report documents executed SQL only. It does not establish IBM Bob authorship, production safety, or behavior outside the reported contract and schedules.

