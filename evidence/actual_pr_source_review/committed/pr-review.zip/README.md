# Cutover PR review handoff

Extract into a new folder. Open pr-summary.md for the verdict/counterexample and
review.html for the offline trace and SQL. Relative evidence links work within
this extracted folder. The HTML displays recorded evidence; it does not reverify
itself or execute SQL. Full inputs and original reports remain in comparison.zip.

With the current Cutover local starter/check-out available, independently replay:

    python -m cutover.audit_bundle --bundle comparison.zip --markdown freshly-audited.md --html freshly-audited.html

Exit0 means every retained plan passes; exit1 means verified evidence includes a
blocked plan (including a blocked original before a passing repair); exit2 means
unverified. Do not overwrite the original notes or relabel original runs.

SHA256SUMS.json identifies these packaged bytes; it is unsigned and is not proof
of publisher identity. The source Git metadata is local recorded provenance, not
proof of whole-application execution at those commits. Only comparison.zip is
independently replayed by the command; it does not authenticate these outer notes.
A passing PR kit, or requested blocked Bob workspace, is included when generated;
inspect its own README before use. Export does not invoke Bob or install a gate.

This handoff contains the SQL/contract inputs you chose to export. Review what
you share. Local execution logs stay in the original review folder.
