# Independently verified Cutover packet

Every retained report and packaged companion file passed independent replay and format verification. This is bounded SQLite evidence, not production approval or authenticated authorship.

## Review verdict

| Executed plan | Verdict | Full suite passed | Completed-rollout failures | Migration-window failures |
| --- | --- | --- | --- | --- |
| Baseline | BLOCKED | 108/124 | 0/76 | 16/48 |
| Candidate | PASS | 124/124 | 0/76 | 0/48 |

Window counts describe each plan separately. Different statement sequences create different tested boundaries; a smaller denominator does not imply equivalent coverage. The packet retains both full reports.

## Measured comparison

~~~json
{
  "paired_probes": 76,
  "regressed_probe_ids": [],
  "resolved": 0,
  "regressed": 0,
  "window_probes_paired": false,
  "interpretation": "Different SQL sequences: statement windows are evaluated separately, not paired by step number."
}
~~~

## Executed SQL changes

Textual differences do not establish which SQL line caused the measured change.

### migration

Changed lines (- baseline, + candidate). Line endings are normalized for this display; the full SQL below and the packet retain the executed strings.

~~~diff
--- baseline/migration.sql
+++ candidate/migration.sql
@@ -1,5 +1,4 @@
 ALTER TABLE stock_items ADD COLUMN fulfillment_bin TEXT;
-UPDATE stock_items SET fulfillment_bin = pick_bin;
 CREATE TRIGGER sync_old_update AFTER UPDATE OF pick_bin ON stock_items
 WHEN NEW.pick_bin IS NOT NEW.fulfillment_bin
 BEGIN
@@ -15,3 +14,4 @@
 BEGIN
   UPDATE stock_items SET fulfillment_bin = NEW.pick_bin WHERE id = NEW.id;
 END;
+UPDATE stock_items SET fulfillment_bin = pick_bin;
~~~

Pinned baseline:

~~~sql
ALTER TABLE stock_items ADD COLUMN fulfillment_bin TEXT;
UPDATE stock_items SET fulfillment_bin = pick_bin;
CREATE TRIGGER sync_old_update AFTER UPDATE OF pick_bin ON stock_items
WHEN NEW.pick_bin IS NOT NEW.fulfillment_bin
BEGIN
  UPDATE stock_items SET fulfillment_bin = NEW.pick_bin WHERE id = NEW.id;
END;
CREATE TRIGGER sync_new_update AFTER UPDATE OF fulfillment_bin ON stock_items
WHEN NEW.fulfillment_bin IS NOT NEW.pick_bin
BEGIN
  UPDATE stock_items SET pick_bin = NEW.fulfillment_bin WHERE id = NEW.id;
END;
CREATE TRIGGER sync_old_insert AFTER INSERT ON stock_items
WHEN NEW.fulfillment_bin IS NULL
BEGIN
  UPDATE stock_items SET fulfillment_bin = NEW.pick_bin WHERE id = NEW.id;
END;
~~~

Current candidate:

~~~sql
ALTER TABLE stock_items ADD COLUMN fulfillment_bin TEXT;
CREATE TRIGGER sync_old_update AFTER UPDATE OF pick_bin ON stock_items
WHEN NEW.pick_bin IS NOT NEW.fulfillment_bin
BEGIN
  UPDATE stock_items SET fulfillment_bin = NEW.pick_bin WHERE id = NEW.id;
END;
CREATE TRIGGER sync_new_update AFTER UPDATE OF fulfillment_bin ON stock_items
WHEN NEW.fulfillment_bin IS NOT NEW.pick_bin
BEGIN
  UPDATE stock_items SET pick_bin = NEW.fulfillment_bin WHERE id = NEW.id;
END;
CREATE TRIGGER sync_old_insert AFTER INSERT ON stock_items
WHEN NEW.fulfillment_bin IS NULL
BEGIN
  UPDATE stock_items SET fulfillment_bin = NEW.pick_bin WHERE id = NEW.id;
END;
UPDATE stock_items SET fulfillment_bin = pick_bin;
~~~

## Pinned baseline report

# Cutover review: Imported SQL: supplied-baseline.sql

**Verdict:** BLOCKED — 108/124 rollout and window probes passed.

**Contract:** Warehouse / bin relocation (`custom`)

| Evidence group | Passed | Total |
| --- | ---: | ---: |
| Same-version baseline | 8 | 8 |
| Completed rollout | 76 | 76 |
| Migration-statement windows | 32 | 48 |

The baseline is separate from the rollout total. Each probe executes against a fresh disposable SQLite database and checks acknowledged values against an independent ledger.

## Shortest observed failing replay

Probe: **`window_write_after_2-0`** — Old write after migration step 2/5 → new read

Input:

~~~json
"R-07"
~~~

Row shown in this replay: `11`.

Seed IDs checked before this verdict:

~~~json
[
  11
]
~~~

### 1. migration.statement.0 — pass

Connection: **migration**.

Executed SQL:

~~~sql
ALTER TABLE stock_items ADD COLUMN fulfillment_bin TEXT;
~~~

Migration statement executed against a fresh in-memory database.

### 2. migration.statement.1 — pass

Connection: **migration**.

Executed SQL:

~~~sql
UPDATE stock_items SET fulfillment_bin = pick_bin;
~~~

Migration statement executed against a fresh in-memory database.

### 3. old.write — pass

Connection: **old**.

Executed SQL:

~~~sql
UPDATE stock_items SET pick_bin = :value WHERE id = :id
~~~

Bound inputs:

~~~json
{
  "id": 11,
  "value": "R-07"
}
~~~

Write acknowledged; independent ledger updated.

### 4. old.read — pass

Connection: **old**.

Executed SQL:

~~~sql
SELECT id, pick_bin AS value FROM stock_items ORDER BY id
~~~

Expected ledger:

~~~json
{
  "11": "R-07",
  "22": "B-02",
  "33": "C-03"
}
~~~

Observed:

~~~json
{
  "11": "R-07",
  "22": "B-02",
  "33": "C-03"
}
~~~

All 3 records match the independent write ledger.

### 5. migration.statement.2 — pass

Connection: **migration**.

Executed SQL:

~~~sql
CREATE TRIGGER sync_old_update AFTER UPDATE OF pick_bin ON stock_items
WHEN NEW.pick_bin IS NOT NEW.fulfillment_bin
BEGIN
  UPDATE stock_items SET fulfillment_bin = NEW.pick_bin WHERE id = NEW.id;
END;
~~~

Migration statement executed against a fresh in-memory database.

### 6. migration.statement.3 — pass

Connection: **migration**.

Executed SQL:

~~~sql
CREATE TRIGGER sync_new_update AFTER UPDATE OF fulfillment_bin ON stock_items
WHEN NEW.fulfillment_bin IS NOT NEW.pick_bin
BEGIN
  UPDATE stock_items SET pick_bin = NEW.fulfillment_bin WHERE id = NEW.id;
END;
~~~

Migration statement executed against a fresh in-memory database.

### 7. migration.statement.4 — pass

Connection: **migration**.

Executed SQL:

~~~sql
CREATE TRIGGER sync_old_insert AFTER INSERT ON stock_items
WHEN NEW.fulfillment_bin IS NULL
BEGIN
  UPDATE stock_items SET fulfillment_bin = NEW.pick_bin WHERE id = NEW.id;
END;
~~~

Migration statement executed against a fresh in-memory database.

### 8. new.read — fail

Connection: **new**.

Executed SQL:

~~~sql
SELECT id, fulfillment_bin AS value FROM stock_items ORDER BY id
~~~

Expected ledger:

~~~json
{
  "11": "R-07",
  "22": "B-02",
  "33": "C-03"
}
~~~

Observed:

~~~json
{
  "11": "A-01",
  "22": "B-02",
  "33": "C-03"
}
~~~

A reader cannot see the latest acknowledged data.

Failure: **data\_mismatch** — A reader cannot see the latest acknowledged data.

## Evidence identity

- Plan SHA-256: `2faf11f8d30c1a92e396b85f302ae0fd25c716c3ba935e1bbf924526a277bd7b`
- Contract SHA-256: `6455c1c197d93e0bdd5915232d94e4558514efe9d3245d576d970172e8f9b5a5`
- Suite SHA-256: `dbd9cb724455cadced8634b8ad2ceab343b8ba47dd4a9f2d880a4a7381ba0f86`
- Engine SHA-256: `9b315f8a9b9d434f4de5f46b94aefcc15b635bab64ffd69f1bae989361e50aeb`
- SQLite version: `3.50.4`
- Generated UTC: `2026-09-27T08:37:41.000829+00:00`

## Scope and limits

SQLite user-supplied contract, separate migration/old/new connections to one disposable in-memory database, target-column postconditions, every seeded record for update probes, every ordered seed pair across rotating two-write probes, two new record IDs for insert probes, bounded sequential interleavings and old-worker read checks at every completed statement boundary. Not a production deployment approval.

- No concurrent transactions, lock timing or network failures modeled.
- No PostgreSQL, MySQL or ORM behavior claimed.
- Writes between migration statements are modeled; mid-statement interruption and lock timing are not.
- Contract/drop-column phase is deferred until old workers and rollback windows are retired.
- Each ordered seed pair is covered somewhere in a passing full suite, but not under every schedule and payload combination.
- Passing covers only the fixed adapters, seed data and reported schedules.

This report documents executed SQL only. It does not establish IBM Bob authorship, production safety, or behavior outside the reported contract and schedules.


## Current candidate report

# Cutover review: Imported SQL: supplied-candidate.sql

**Verdict:** PASS — 124/124 rollout and window probes passed.

**Contract:** Warehouse / bin relocation (`custom`)

| Evidence group | Passed | Total |
| --- | ---: | ---: |
| Same-version baseline | 8 | 8 |
| Completed rollout | 76 | 76 |
| Migration-statement windows | 48 | 48 |

The baseline is separate from the rollout total. Each probe executes against a fresh disposable SQLite database and checks acknowledged values against an independent ledger.

## Example passing migration-window replay

Probe: **`window_write_after_0-0`** — Old write after migration step 0/5 → new read

Input:

~~~json
"R-07"
~~~

Row shown in this replay: `11`.

Seed IDs checked before this verdict:

~~~json
[
  11,
  22,
  33
]
~~~

### 1. old.write — pass

Connection: **old**.

Executed SQL:

~~~sql
UPDATE stock_items SET pick_bin = :value WHERE id = :id
~~~

Bound inputs:

~~~json
{
  "id": 11,
  "value": "R-07"
}
~~~

Write acknowledged; independent ledger updated.

### 2. old.read — pass

Connection: **old**.

Executed SQL:

~~~sql
SELECT id, pick_bin AS value FROM stock_items ORDER BY id
~~~

Expected ledger:

~~~json
{
  "11": "R-07",
  "22": "B-02",
  "33": "C-03"
}
~~~

Observed:

~~~json
{
  "11": "R-07",
  "22": "B-02",
  "33": "C-03"
}
~~~

All 3 records match the independent write ledger.

### 3. migration.statement.0 — pass

Connection: **migration**.

Executed SQL:

~~~sql
ALTER TABLE stock_items ADD COLUMN fulfillment_bin TEXT;
~~~

Migration statement executed against a fresh in-memory database.

### 4. migration.statement.1 — pass

Connection: **migration**.

Executed SQL:

~~~sql
CREATE TRIGGER sync_old_update AFTER UPDATE OF pick_bin ON stock_items
WHEN NEW.pick_bin IS NOT NEW.fulfillment_bin
BEGIN
  UPDATE stock_items SET fulfillment_bin = NEW.pick_bin WHERE id = NEW.id;
END;
~~~

Migration statement executed against a fresh in-memory database.

### 5. migration.statement.2 — pass

Connection: **migration**.

Executed SQL:

~~~sql
CREATE TRIGGER sync_new_update AFTER UPDATE OF fulfillment_bin ON stock_items
WHEN NEW.fulfillment_bin IS NOT NEW.pick_bin
BEGIN
  UPDATE stock_items SET pick_bin = NEW.fulfillment_bin WHERE id = NEW.id;
END;
~~~

Migration statement executed against a fresh in-memory database.

### 6. migration.statement.3 — pass

Connection: **migration**.

Executed SQL:

~~~sql
CREATE TRIGGER sync_old_insert AFTER INSERT ON stock_items
WHEN NEW.fulfillment_bin IS NULL
BEGIN
  UPDATE stock_items SET fulfillment_bin = NEW.pick_bin WHERE id = NEW.id;
END;
~~~

Migration statement executed against a fresh in-memory database.

### 7. migration.statement.4 — pass

Connection: **migration**.

Executed SQL:

~~~sql
UPDATE stock_items SET fulfillment_bin = pick_bin;
~~~

Migration statement executed against a fresh in-memory database.

### 8. new.read — pass

Connection: **new**.

Executed SQL:

~~~sql
SELECT id, fulfillment_bin AS value FROM stock_items ORDER BY id
~~~

Expected ledger:

~~~json
{
  "11": "R-07",
  "22": "B-02",
  "33": "C-03"
}
~~~

Observed:

~~~json
{
  "11": "R-07",
  "22": "B-02",
  "33": "C-03"
}
~~~

All 3 records match the independent write ledger.

### 9. target.check — pass

Connection: **migration**.

Executed SQL:

~~~sql
SELECT id, "fulfillment_bin" AS value FROM "stock_items" ORDER BY id
~~~

Expected ledger:

~~~json
{
  "11": "R-07",
  "22": "B-02",
  "33": "C-03"
}
~~~

Observed:

~~~json
{
  "11": "R-07",
  "22": "B-02",
  "33": "C-03"
}
~~~

Required target column matches the independent write ledger.

**A pass is bounded to this suite; it is not a deployment approval.**

## Evidence identity

- Plan SHA-256: `d36355aa38b1f4bc7c307a183b507f8bdf6b6bf87cc7f568f28f8b7693c15dfa`
- Contract SHA-256: `6455c1c197d93e0bdd5915232d94e4558514efe9d3245d576d970172e8f9b5a5`
- Suite SHA-256: `dbd9cb724455cadced8634b8ad2ceab343b8ba47dd4a9f2d880a4a7381ba0f86`
- Engine SHA-256: `9b315f8a9b9d434f4de5f46b94aefcc15b635bab64ffd69f1bae989361e50aeb`
- SQLite version: `3.50.4`
- Generated UTC: `2026-09-27T08:37:40.463209+00:00`

## Scope and limits

SQLite user-supplied contract, separate migration/old/new connections to one disposable in-memory database, target-column postconditions, every seeded record for update probes, every ordered seed pair across rotating two-write probes, two new record IDs for insert probes, bounded sequential interleavings and old-worker read checks at every completed statement boundary. Not a production deployment approval.

- No concurrent transactions, lock timing or network failures modeled.
- No PostgreSQL, MySQL or ORM behavior claimed.
- Writes between migration statements are modeled; mid-statement interruption and lock timing are not.
- Contract/drop-column phase is deferred until old workers and rollback windows are retired.
- Each ordered seed pair is covered somewhere in a passing full suite, but not under every schedule and payload combination.
- Passing covers only the fixed adapters, seed data and reported schedules.

This report documents executed SQL only. It does not establish IBM Bob authorship, production safety, or behavior outside the reported contract and schedules.


## Baseline SQL source

Local Git snapshot (not a signature):

```json
{
  "commit": "4bf0e9c31aeb2add321c8b4450efa1b494716444",
  "path": "db/relocation.sql",
  "blob": "687de3b7ae3dd0798bb10cf86057ce98af8b2c8c"
}
```

Exact bytes are retained in `inputs/supplied-baseline.sql`. Only migration SQL comes from Git; adapters and contract are the supplied project inputs.

## Candidate SQL source

```json
{
  "path": "db/relocation.sql",
  "path_scope": "Repository path at candidate commit",
  "snapshot": "inputs/supplied-candidate.sql",
  "sha256": "371aab8a669c64a52964b6402ebf17324ad9bb1f5da6ebaec61ff330abd4e0f0",
  "commit": "f973f99fc0b83b7f645e7b534c740d66e7dd535e",
  "blob": "290f49150911a80dc9f0fe445570e34017456ebf"
}
```

Byte hash of the retained SQL snapshot, including any BOM and line endings. Adapters still come from candidate.json; this is not a whole-PR verification or signature.
