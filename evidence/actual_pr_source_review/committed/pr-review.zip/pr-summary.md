# Cutover PR review: candidate PASS

| Executed plan | Full suite | Completed-rollout failures | Migration-window failures |
| --- | --- | --- | --- |
| Original baseline | BLOCKED 108/124 | 0/76 | 16/48 |
| Candidate | PASS 124/124 | 0/76 | 0/48 |

Window counts describe each plan separately; different SQL sequences are not paired by step number.

## Original counterexample retained; current candidate passed

~~~text
Recorded counterexample: "window_write_after_2-0"
Sequence: [{"action":"migration.statement.0","status":"pass"},{"action":"migration.statement.1","status":"pass"},{"action":"old.write","status":"pass"},{"action":"old.read","status":"pass"},{"action":"migration.statement.2","status":"pass"},{"action":"migration.statement.3","status":"pass"},{"action":"migration.statement.4","status":"pass"},{"action":"new.read","status":"fail"}]
Expected: {"11":"R-07","22":"B-02","33":"C-03"}
Actual: {"11":"A-01","22":"B-02","33":"C-03"}
Failure: {"kind":"data_mismatch","message":"A reader cannot see the latest acknowledged data.","expected":{"11":"R-07","22":"B-02","33":"C-03"},"actual":{"11":"A-01","22":"B-02","33":"C-03"},"action":"new.read","step":8}
This is a recorded bounded rehearsal, not a production incident or single-line cause.
~~~

Display is bounded; inspect the full recorded trace and SQL in [review.html](review.html).

## SQL source identity

~~~json
{
  "original_sql": {
    "commit": "4bf0e9c31aeb2add321c8b4450efa1b494716444",
    "path": "db/relocation.sql",
    "blob": "687de3b7ae3dd0798bb10cf86057ce98af8b2c8c"
  },
  "candidate_sql": {
    "path": "db/relocation.sql",
    "path_scope": "Repository path at candidate commit",
    "snapshot": "inputs/supplied-candidate.sql",
    "sha256": "371aab8a669c64a52964b6402ebf17324ad9bb1f5da6ebaec61ff330abd4e0f0",
    "commit": "f973f99fc0b83b7f645e7b534c740d66e7dd535e",
    "blob": "290f49150911a80dc9f0fe445570e34017456ebf"
  }
}
~~~

## Candidate evidence identity

~~~json
{
  "plan_hash": "d36355aa38b1f4bc7c307a183b507f8bdf6b6bf87cc7f568f28f8b7693c15dfa",
  "contract_hash": "6455c1c197d93e0bdd5915232d94e4558514efe9d3245d576d970172e8f9b5a5",
  "suite_hash": "dbd9cb724455cadced8634b8ad2ceab343b8ba47dd4a9f2d880a4a7381ba0f86",
  "engine_sha256": "9b315f8a9b9d434f4de5f46b94aefcc15b635bab64ffd69f1bae989361e50aeb"
}
~~~

[Full review and SQL changes](review.md) · [Offline trace viewer](review.html) · [Replayable packet](comparison.zip)

Generated only after independent comparison audit and any requested packaging checks. Bounded sequential SQLite evidence, not whole-application verification, signed provenance or production approval. Review the supplied contract/adapters and operational rollout separately.
