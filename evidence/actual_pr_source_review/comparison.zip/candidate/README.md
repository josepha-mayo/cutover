# Cutover release review

Verdict: PASS (124/124 probes)
Plan SHA-256: d36355aa38b1f4bc7c307a183b507f8bdf6b6bf87cc7f568f28f8b7693c15dfa
Contract SHA-256: 6455c1c197d93e0bdd5915232d94e4558514efe9d3245d576d970172e8f9b5a5
Engine SHA-256: 9b315f8a9b9d434f4de5f46b94aefcc15b635bab64ffd69f1bae989361e50aeb

The JSON and Markdown record one executed rehearsal. From a checkout of the
Cutover source with the matching engine hash, rerun every replayable claim:

    python -m cutover.audit_report --contract contract.json --plan plan.json --report report.json

Exit 0 means verified pass, 1 means verified block, and 2 means unverified.
To verify this entire ZIP, including its Markdown and any witness, run
`python -m cutover.audit_bundle --bundle PATH_TO_ZIP` from the source checkout.
A passing report is bounded evidence, not deployment approval. The archive
is not signed; creation time, runtime and host SQLite version are self-reported.
