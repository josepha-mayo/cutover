# Cutover before/after release review

These are two independent, fresh SQL rehearsals of the same contract and evaluator.
The `baseline/` and `candidate/` folders each contain a complete review packet.
Run the audit command in each folder README from a checkout of Cutover with
the matching engine hash. The auditor replays every retained claim.

To verify both reports, the comparison manifest, reviews and witnesses in
one step, run `python -m cutover.audit_bundle --bundle PATH_TO_ZIP`.

Baseline: blocked 108/124 · 2faf11f8d30c1a92e396b85f302ae0fd25c716c3ba935e1bbf924526a277bd7b
Candidate: pass 124/124 · d36355aa38b1f4bc7c307a183b507f8bdf6b6bf87cc7f568f28f8b7693c15dfa

The comparison.json file counts paired probes only when their payload and
action sequence match. Different migration SQL sequences have different
statement boundaries, so their window failures are reported separately.
A passing bounded SQLite rehearsal is not production deployment approval.
