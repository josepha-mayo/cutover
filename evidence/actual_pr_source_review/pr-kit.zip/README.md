# Cutover CI handoff kit

Fresh rehearsal: PASS 124/124 bounded probes.
Plan SHA-256: d36355aa38b1f4bc7c307a183b507f8bdf6b6bf87cc7f568f28f8b7693c15dfa
Contract SHA-256: 6455c1c197d93e0bdd5915232d94e4558514efe9d3245d576d970172e8f9b5a5
Engine SHA-256: 9b315f8a9b9d434f4de5f46b94aefcc15b635bab64ffd69f1bae989361e50aeb

## Add this check to your own repository

Inspect and copy only these four files, preserving their paths:

- `.github/workflows/cutover-release-warehouse-bin-relocation.yml`
- `ci/release-warehouse-bin-relocation-contract.json`
- `ci/release-warehouse-bin-relocation-adapters.json`
- `ci/release-warehouse-bin-relocation-migration.sql`

Commit them on a branch and open a pull request. The workflow calls
`josepha-mayo/cutover@8a7895ea6c4a91b5058f50c1bcba6863cc8f96df`; no Cutover clone, engine copy,
package installation or API key is needed in your repository. The
SQL file is the migration source of truth; the adapters JSON contains
only the candidate name and new-worker queries. Keep editing that SQL
file to have later changes rehearsed by the same check. GitHub retains
the independently audited verdict, report and replay packet; an unsafe
migration or unverifiable input fails the job.

The workflow locks the agreed contract hash from this replay. Changing
the schema, old-worker adapters, seed records or payloads fails as
`unverified`, even if the candidate passes the changed test data. JSON
formatting and key order do not affect the lock. Review intentional
contract changes separately before updating the pinned hash; do not
automatically recalculate it inside a pull request. Protect workflow
changes with repository review rules: this hash is not a signature.

The downloaded contract contains the supplied seed data.
Review all four files before committing. Do not overwrite an existing
workflow or input with the same name. Keep the remaining evidence and
unsafe-control files for local review; do not copy the whole archive
into an application repository. A check runs on pull requests; make it
required in your repository settings if your team wants to enforce it.

## Alternatively: add a case inside a Cutover checkout

From a checkout of the Cutover repository, verify this downloaded ZIP
and preview the files it would add, then apply it explicitly:

    python -m ci.install_kit --kit path/to/downloaded-kit.zip
    python -m ci.install_kit --kit path/to/downloaded-kit.zip --apply
    python -m ci.install_kit --kit path/to/downloaded-kit.zip --verify-installed

The installer rejects path or slug collisions, independently replays
the report (and unsafe control, if present), then adds only the passing
inputs and one manifest entry. Or copy these exact two JSON files:
`ci/release-warehouse-bin-relocation-contract.json` and `ci/release-warehouse-bin-relocation-candidate.json`,
and append `manifest-entry.json` to `ci/cases.json` manually. Run:

    python -m ci.discover_cases
    python -m cutover.audit_report --contract ci/release-warehouse-bin-relocation-contract.json --plan ci/release-warehouse-bin-relocation-candidate.json --report evidence/report.json

Commit the files and open a PR. GitHub Actions will create a separate
review job with retained evidence for this case. This kit contains
freshly executed and independently replayed bounded SQLite evidence,
not deployment approval. Check
the source SQL, privacy, dialect and operational rollback plan yourself.
The archive is not signed; its self-reported timestamps are not proof
of origin or IBM Bob authorship.

## Prove this gate can go red

The same contract also blocked the unsafe control at 108/124 probes. Its first failing write is retained in `evidence/unsafe-control-report.json` and `evidence/unsafe-control-witness.py`. From the repository checkout, run:

    python ci/review_gate.py --contract ci/release-warehouse-bin-relocation-contract.json --plan ci/release-warehouse-bin-relocation-unsafe-control.json --output-dir work/ci-negative-control
    # Expected exit 1 and classification verified_block.
    python ci/review_gate.py --contract ci/release-warehouse-bin-relocation-contract.json --plan ci/release-warehouse-bin-relocation-candidate.json --output-dir work/ci-positive-control
    # Expected exit 0 and classification verified_pass.

The unsafe control is not in `manifest-entry.json`: do not add it to a normal green PR.
