# Cutover CI handoff kit

Fresh rehearsal: PASS 124/124 bounded probes.
Plan SHA-256: e025fa3c3e4fb4acc155505ce4d0f978896ae9b5b199f5f841a5e15298c61a18
Contract SHA-256: 360b26dff33b79ea62bb12cd150d99dbb39ce0df764783b1dcf30d613bc2b7d5
Engine SHA-256: 9b315f8a9b9d434f4de5f46b94aefcc15b635bab64ffd69f1bae989361e50aeb

## Add this check to your own repository

Inspect and copy only these four files, preserving their paths:

- `.github/workflows/cutover-release-dispatch-handover.yml`
- `ci/release-dispatch-handover-contract.json`
- `ci/release-dispatch-handover-adapters.json`
- `ci/release-dispatch-handover-migration.sql`

Commit them on a branch and open a pull request. The workflow calls
`josepha-mayo/cutover@a5bf69f6e8f94788eade58691d292941e009f8ac`; no Cutover clone, engine copy,
package installation or API key is needed in your repository. The
SQL file is the migration source of truth; the adapters JSON contains
only the candidate name and new-worker queries. Keep editing that SQL
file to have later changes rehearsed by the same check. GitHub retains
the independently audited verdict, report and replay packet; an unsafe
migration or unverifiable input fails the job.

The downloaded contract contains the supplied synthetic seed data.
Review all four files before committing. Do not overwrite an existing
workflow or input with the same name. Keep the remaining evidence and
unsafe-control files for local review; do not copy the whole archive
into an application repository. A check runs on pull requests; make it
required in your repository settings if your team wants to enforce it.

## Alternatively: add a case inside a Cutover checkout

From a checkout of the Cutover repository, verify this downloaded ZIP
and preview the files it would add, then apply it explicitly:

    python -m ci.install_kit --kit path/to/downloaded-kit.zip
    python -m ci.install_kit --kit path/to/downloaded-kit.zip --apply
    python -m ci.install_kit --kit path/to/downloaded-kit.zip --verify-installed

The installer rejects path or slug collisions, independently replays
the report (and unsafe control, if present), then adds only the passing
inputs and one manifest entry. Or copy these exact two JSON files:
`ci/release-dispatch-handover-contract.json` and `ci/release-dispatch-handover-candidate.json`,
and append `manifest-entry.json` to `ci/cases.json` manually. Run:

    python -m ci.discover_cases
    python -m cutover.audit_report --contract ci/release-dispatch-handover-contract.json --plan ci/release-dispatch-handover-candidate.json --report evidence/report.json

Commit the files and open a PR. GitHub Actions will create a separate
review job with retained evidence for this case. This kit contains
freshly executed and independently replayed synthetic SQLite evidence,
not deployment approval. Check
the source SQL, privacy, dialect and operational rollback plan yourself.
The archive is not signed; its self-reported timestamps are not proof
of origin or IBM Bob authorship.

## Prove this gate can go red

The same contract also blocked the unsafe control at 44/100 probes. Its first failing write is retained in `evidence/unsafe-control-report.json` and `evidence/unsafe-control-witness.py`. From the repository checkout, run:

    python ci/review_gate.py --contract ci/release-dispatch-handover-contract.json --plan ci/release-dispatch-handover-unsafe-control.json --output-dir work/ci-negative-control
    # Expected exit 1 and classification verified_block.
    python ci/review_gate.py --contract ci/release-dispatch-handover-contract.json --plan ci/release-dispatch-handover-candidate.json --output-dir work/ci-positive-control
    # Expected exit 0 and classification verified_pass.

The unsafe control is not in `manifest-entry.json`: do not add it to a normal green PR.
