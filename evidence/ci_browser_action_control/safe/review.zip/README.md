# Cutover release review

Verdict: PASS (124/124 probes)
Plan SHA-256: e025fa3c3e4fb4acc155505ce4d0f978896ae9b5b199f5f841a5e15298c61a18
Contract SHA-256: 360b26dff33b79ea62bb12cd150d99dbb39ce0df764783b1dcf30d613bc2b7d5
Engine SHA-256: 9b315f8a9b9d434f4de5f46b94aefcc15b635bab64ffd69f1bae989361e50aeb

The JSON and Markdown record one executed rehearsal. From a checkout of the
Cutover source with the matching engine hash, rerun every replayable claim:

    python -m cutover.audit_report --contract contract.json --plan plan.json --report report.json

Exit 0 means verified pass, 1 means verified block, and 2 means unverified.
To verify this entire ZIP, including its Markdown and any witness, run
`python -m cutover.audit_bundle --bundle PATH_TO_ZIP` from the source checkout.
A passing report is bounded evidence, not deployment approval. The archive
is not signed; creation time, runtime and host SQLite version are self-reported.
