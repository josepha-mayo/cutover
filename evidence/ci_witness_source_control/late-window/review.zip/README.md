# Cutover release review

Verdict: BLOCKED (108/124 probes)
Plan SHA-256: fc752d050e87e4e7a5157003298da7496c30100a00826af13ca3606bca364b44
Contract SHA-256: 6455c1c197d93e0bdd5915232d94e4558514efe9d3245d576d970172e8f9b5a5
Engine SHA-256: 9b315f8a9b9d434f4de5f46b94aefcc15b635bab64ffd69f1bae989361e50aeb

The JSON and Markdown record one executed rehearsal. From a checkout of the
Cutover source with the matching engine hash, rerun every replayable claim:

    python -m cutover.audit_report --contract contract.json --plan plan.json --report report.json

Exit 0 means verified pass, 1 means verified block, and 2 means unverified.
To verify this entire ZIP, including its Markdown and any witness, run
`python -m cutover.audit_bundle --bundle PATH_TO_ZIP` from the source checkout.
A passing report is bounded evidence, not deployment approval. The archive
is not signed; creation time, runtime and host SQLite version are self-reported.

Run `python -I witness.py` to reproduce the recorded data gap.
